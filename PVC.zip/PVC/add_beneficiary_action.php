<?php
    include "validate_user.php";
    include "connect.php";
   
    include "session_timeout.php";

    $walletaddress = mysqli_real_escape_string($conn, $_POST["walletaddress"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $phno = mysqli_real_escape_string($conn, $_POST["phno"]);

    $id = $_SESSION['loggedIn_user_id'];
    $sql0 = "SELECT user_id FROM user WHERE   
                                                wallet_address='".$walletaddress."' AND
                                                email='".$email."' AND
                                                phone_no='".$phno."' ";
    $result = $conn->query($sql0);

    $success = 0;
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $beneficiary_id = $row["user_id"];

        if ($id != $beneficiary_id) {
            $sql1 = "INSERT INTO beneficiary".$id." VALUES(
                        NULL,
                        '$beneficiary_id',
                        '$email',
                        '$phno',
                        '$walletaddress'
                    )";

            if (($conn->query($sql1) === TRUE)) {
                $success = 1;
            }
        }
        else {
            $success = -1;
        }
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Refresh" content="3; url =./add_beneficiary.php"/>
    <link rel="stylesheet" href="action_style.css">
    <style>
    body{
        background-color:black;
    }
    p{
        background-color:white;
    }
    </style>
</head>

<body>
    <div class="flex-container">
        <div class="flex-item">
            <?php
            if ($success == 1) { ?>
                <p id="info"><?php echo "Beneficiary successfully added !\n"; ?></p>
            <?php } ?>

            <?php
            if ($success == 0) { ?>
                <p id="info"><?php echo "Invalid data entered/Connection error !\n"; ?></p>
            <?php } ?>

            <?php
            if ($success == -1) { ?>
                <p id="info"><?php echo "Can't add self as beneficiary !\n"; ?></p>
            <?php } ?>
        </div>

        <div class="flex-item">
            <a href="./beneficiary.php" class="button">Go Back</a>
        </div>
    </div>

</body>
</html>
