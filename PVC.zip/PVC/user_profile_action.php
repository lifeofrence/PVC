<?php
    /* Avoid multiple sessions warning
    Check if session is set before starting a new one. */
    if(!isset($_SESSION)) {
        session_start();
    }

    include "validate_user.php";
    include "connect.php";
   // include "user_navbar.php";
   // include "user_sidebar.php";
    include "session_timeout.php";
    $id = $_SESSION['loggedIn_user_id'];

    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $address = mysqli_real_escape_string($conn, $_POST["address"]);


    $sql0 = "UPDATE user 
    SET email = '$email', address = '$address'
                            WHERE user_id=".$id;
                                               
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Refresh" content="3; url =./user_profile.php"/>
    <link rel="stylesheet" href="action_style.css">
    <style>
    body{
        background-color:black;
    }
    p{
        background-color:white;
    }
    </style>
</head>

<body>
    <div class="flex-container">
        <div class="flex-item">
            <?php
                if (($conn->query($sql0) === TRUE)) { ?>
                    <p id="info"><?php echo "Values Updated Successfully !"; ?></p>
                <?php
                }
                else { ?>
                    <p id="info"><?php echo "Error: " . $sql0 . "<br>" . $conn->error . "<br>"; ?></p>
                <?php
                }
            ?>
        </div>
       

    </div>

</body>
</html>
