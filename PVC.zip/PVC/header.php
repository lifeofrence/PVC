<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="header_style.css">
</head>

<body>
    <div class="flex-container-header">
        <div class="flex-item-header">
            <img src="img/vunacoin.jpg" onclick="eEgg_func()" width="100" height="100" radius="50" >
        </div>
        <div class="flex-item-header">
            <h1>VUNACOIN</h1>
        </div>
    </div>

</body>
</html>
