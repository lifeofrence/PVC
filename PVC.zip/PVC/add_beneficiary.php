<?php
    include "validate_user.php";
    include "connect.php";
    include "session_timeout.php";
?>

<!DOCTYPE html>
<html>
  <head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>vunacoin</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
   <link rel = "stylesheet" href = "https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
    <!-- Custom Font Icons CSS-->
    <link rel="stylesheet" href="css/font.css">
    <link rel="stylesheet" href="css/transctions_style.css">
    <!-- Google fonts - Muli-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Muli:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
   
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.ico">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
  <header class="header">   
      <nav class="navbar navbar-expand-lg">
        <div class="search-panel">
          <div class="search-inner d-flex align-items-center justify-content-center">
            <div class="close-btn">Close <i class="fa fa-close"></i></div>
            <form id="searchForm" action="#">
              <div class="form-group">
               
              </div>
            </form>
          </div>
        </div>
        <div class="container-fluid d-flex align-items-center justify-content-between">
          <div class="navbar-header">
            <!-- Navbar Header--><a href="./user_home.php" class="navbar-brand">
              <div class="brand-text brand-big visible text-uppercase"><strong class="text-primary">vuna</strong><strong>coin</strong></div>
              <div class="brand-text brand-sm"><strong class="text-primary">vuna</strong><strong>coin</strong></div></a>
            <!-- Sidebar Toggle Btn-->
            <button class="sidebar-toggle"><i class="fa fa-long-arrow-left"></i></button>
          </div>
         
            <!-- Tasks end-->
           
            <!-- Log out               -->
            <div class="list-inline-item logout">                   <a id="logout" href="./logout_action.php" class="nav-link">Logout </a></div>
          </div>
        </div>
      </nav>
    </header>
    <div class="d-flex align-items-stretch">
      <!-- Sidebar Navigation-->
      <nav id="sidebar">
        <!-- Sidebar Header-->
  
        <div class="sidebar-header d-flex align-items-center">
        
        <div class="img-fluid rounded-circle " width="120" height="120">
          <?php 
          
$id = $_SESSION['loggedIn_user_id'];

// If upload button is clicked ... 
$db = mysqli_connect("localhost", "root", "", "vunacoin"); 

          $sql3 = "SELECT * FROM user WHERE user_id=".$id;
    
            $result2 = mysqli_query($db, $sql3); 
  
          while($data = mysqli_fetch_array($result2)) 
        { 
      
            echo'<img src="img/'.$data['filename'].'" class="img-fluid rounded-circle";>';
          }  ?> 
        
      </div>
          <div class="title">
            
            
          </div>
        </div>
        <!-- Sidebar Navidation Menus--><span class="heading">
    </span>  
    
        <ul class="list-unstyled">
        <li class="active"><a href="./user_home.php"> <i class="fa fa-home"></i>Home </a></li>
                <li class="active"><a href="./user_profile.php"> <i class="fa fa-user"></i>Profile </a></li>
                <li class="active"><a href="./transactions_history.php"> <i class="fa fa-history"></i>Transaction History </a></li>
                <li class="active"><a href="./beneficiary.php"> <i class="fa fa-bar-chart"></i>Transfer Coin </a></li>
                <li class="active"><a href="./logout_action.php"> <i class="icon-logout"></i>Logout </a></li>
        
      </nav>
      <!-- Sidebar Navigation end-->
      <div class="bg-white page-content">
        <div class="page-header">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Add beneficiary</h2>
          </div>
        </div>
        
        <form class="add_customer_form" action="./add_beneficiary_action.php" method="post">
        <div class="flex-container-form_header">
            <h1 id="form_header">Please fill in User details to add as beneficiary...</h1>
        </div>


        <div class="flex-container">
            <div class=container>
                <label>Wallet Address :</label><br>
                <input class="form-control" name="walletaddress" size="25" type="text" required />
            </div>
        </div>

        <div class="flex-container">
            <div class=container>
                <label>Email-ID :</label><br>
                <input class="form-control"  name="email" size="30" type="text" required />
            </div>
            <div  class=container>
                <label>Phone No. :</b></label><br>
                <input class="form-control"  name="phno" size="30" type="text" required />
            </div>
        </div>
            <br>
        <div class="flex-container d-flex align-items-center justify-content-center" >
        <div class="container">
                <button  class="btn btn-primary" type="submit">Add</button>
            </div>
<br>
            <div class="container">
                <a href="./view_beneficiary.php" class="btn btn-secondary">Go Back</a>
            </div>
            
           
           
        </div>

    </form>
                    

                
        <footer class="footer">
          <div class="footer__block block no-margin-bottom">
            <div class="container-fluid text-center">
              <!-- Please do not remove the backlink to us unless you support us at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
               <p class="no-margin-bottom">2021 &copy; veritas university abuja</p>
            </div>
          </div>
        </footer>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="js/charts-home.js"></script>
    <script src="js/front.js"></script>
  </body>
</html>