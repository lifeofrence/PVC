<?php
    /* Avoid multiple sessions warning
    Check if session is set before starting a new one. */
    if(!isset($_SESSION)) {
        session_start();
    }

    include "validate_user.php";
    include "connect.php";
    //include "header.php";
   // include "user_navbar.php";
   // include "user_sidebar.php";
    include "session_timeout.php";

    if (isset($_GET['user_id'])) {
        $sql0 = "DELETE FROM beneficiary".$_SESSION['loggedIn_user_id'].
                " WHERE benef_user_id=".$_GET['user_id'];
    }

    $success = 0;
    if (($conn->query($sql0) === TRUE)) {
        $sql0 = "SELECT MAX(benef_id) FROM beneficiary".$_SESSION['loggedIn_user_id'];
        $result = $conn->query($sql0);
        $row = $result->fetch_assoc();

        $id = $row["MAX(benef_id)"] + 1;
        $sql1 = "ALTER TABLE beneficiary".$_SESSION['loggedIn_user_id']." AUTO_INCREMENT=".$id;

        $conn->query($sql1);
        $success = 1;
    }

    if (isset($_GET['redirect'])) {
        $_SESSION['auto_delete_benef'] = true;
        header("location:./beneficiary.php");
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <meta http-equiv="Refresh" content="3; url =./beneficiary.php"/>
    <link rel="stylesheet" href="action_style.css">
    <style>
    body{
        background-color:black;
    }
    p{
        background-color:white;
    }
    </style>
</head>

<body>
    <div class="flex-container">
        <div class="flex-item">
                <?php
                    if ($success = 1) { ?>
                        <p id="info"><?php echo "Beneficiary Deleted Successfully !"; ?></p>
                    <?php
                    }
                    else { ?>
                        <p id="info"><?php echo "Error: " . $conn->error . "<br>"; ?></p>
                    <?php
                    }
                ?>
        </div>
        <?php $conn->close(); ?>

        <div class="flex-item">
            <a href="./beneficiary.php" class="button">Go Back</a>
        </div>

    </div>

</body>
</html>
