


<?php 

error_reporting(0); 
?> 
<?php 
  if(!isset($_SESSION)) {
    session_start();
}
$id = $_SESSION['loggedIn_user_id'];

  // If upload button is clicked ... 
  $db = mysqli_connect("localhost", "root", "", "vunacoin"); 

  if (isset($_POST['upload'])) { 

  

    $filename = $_FILES["uploadfile"]["name"]; 

    $tempname = $_FILES["uploadfile"]["tmp_name"];     

        $folder = "img/".$filename; 

          

   

  

        // Get all the submitted data from the form 

        $sql = "UPDATE user  
        SET filename ='$filename'
            WHERE user_id=".$id;


        // Execute query 

        mysqli_query($db, $sql); 

          

        // Now let's move the uploaded image into the folder: image 

        if (move_uploaded_file($tempname, $folder))  { 

           echo "Image uploaded successfully"; 

        }else{ 

           echo "Failed to upload image"; 

      } 
      
  } 
  //echo $id;
  $sql0 = "SELECT * FROM user WHERE user_id=".$id;
     
  $result = mysqli_query($db, $sql0); 

  while($data = mysqli_fetch_array($result)) 
  { 
    echo $data['filename'];
    echo'<img src="img/'.$data['filename'].'">';
  } 


?> 

  
<!DOCTYPE html> 
<html> 
<head> 
<meta http-equiv="Refresh" content="0; url =./user_profile.php"/>
<title>Image Upload</title> 

<link rel="stylesheet" type= "text/css" href ="style.css"/> 

<div id="content"> 

  

  <form method="POST" action="" enctype="multipart/form-data"> 

      <input type="file" name="uploadfile" value=""/> 

        

      <div> 

          <button type="submit" name="upload">UPLOAD</button> 

        </div> 

  </form> 
</div> 
</body> 
</html>
