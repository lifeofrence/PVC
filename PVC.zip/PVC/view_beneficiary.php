<?php
    /* Avoid multiple sessions warning
    Check if session is set before starting a new one. */
    if(!isset($_SESSION)) {
        session_start();
    }

    include "validate_user.php";
    include "connect.php";
   
    include "verify_beneficiary.php";
    include "session_timeout.php";

    if (isset($_SESSION['loggedIn_user_id'])) {
        $sql0 = "SELECT * FROM beneficiary".$_SESSION['loggedIn_user_id'];
    }
?>

<!DOCTYPE html>
<html>
  <head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>vunacoin</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
   <link rel = "stylesheet" href = "https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
    <!-- Custom Font Icons CSS-->
    <link rel="stylesheet" href="css/font.css">
    <link rel="stylesheet" href="css/transctions_style.css">
    <!-- Google fonts - Muli-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Muli:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
   
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.ico">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
  <header class="header">   
  <nav class="navbar navbar-expand-lg">
        <div class="search-panel">
          <div class="search-inner d-flex align-items-center justify-content-center">
         
            
          </div>
        </div>
        <div class="container-fluid d-flex align-items-center justify-content-between">
          <div class="navbar-header">
            <!-- Navbar Header-->
            <a href="./user_home.php" class="navbar-brand">
              <div class="brand-text brand-big visible text-uppercase"><strong class="text-primary">vuna</strong><strong>coin</strong></div>
              <div class="brand-text brand-sm"><strong class="text-primary">vuna</strong><strong>coin</strong></div></a>
            <!-- Sidebar Toggle Btn-->
            <button class="sidebar-toggle"><i class="fa fa-long-arrow-left"></i></button>
          </div>
          <div class="right-menu list-inline no-margin-bottom">    
            
            
            <!-- Tasks end-->
           
            <!-- Log out               -->
            <div class="list-inline-item logout">                   <a id="logout" href="./logout_action.php" class="nav-link">Logout <i class="icon-logout"></i></a></div>
          </div>
        </div>
      </nav>
    </header>
    <div class="d-flex align-items-stretch">
      <!-- Sidebar Navigation-->
      <nav id="sidebar">
        <!-- Sidebar Header-->
        <div class="sidebar-header d-flex align-items-center">
        
             <div class="img-fluid rounded-circle " width="120" height="120">
          <?php 
          
$id = $_SESSION['loggedIn_user_id'];

// If upload button is clicked ... 
$db = mysqli_connect("localhost", "root", "", "vunacoin"); 

          $sql3 = "SELECT * FROM user WHERE user_id=".$id;
    
            $result2 = mysqli_query($db, $sql3); 
  
          while($data = mysqli_fetch_array($result2)) 
        { 
      
            echo'<img src="img/'.$data['filename'].'" class="img-fluid rounded-circle";>';
          }  ?> 
        
      </div>
          <div class="title">
            
            
          </div>
        </div>
        <!-- Sidebar Navidation Menus--><span class="heading">
    </span>  
    
        <ul class="list-unstyled">
        <li class="active"><a href="./user_home.php"> <i class="fa fa-home"></i>Home </a></li>
                <li class="active"><a href="./user_profile.php"> <i class="fa fa-user"></i>Profile </a></li>
                <li class="active"><a href="./transactions_history.php"> <i class="fa fa-history"></i>Transaction History </a></li>
                <li class="active"><a href="./beneficiary.php"> <i class="fa fa-bar-chart"></i>Transfer Coin </a></li>
                <li class="active"><a href="./logout_action.php"> <i class="icon-logout"></i>Logout </a></li>
        
      </nav>
      <!-- Sidebar Navigation end-->
      <div class="bg-white page-content">
        <div class="page-header">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">View beneficiaries</h2>
          </div>
        </div>
        
    <div>
        <div class="search-bar" id="the-search-bar">
            <div class="flex-item-search-bar" id="fi-search-bar">
                <a class="btn btn-secondary"href="./add_beneficiary.php">Add beneficiary</a>
            
             <br><br>
    <div>
        <div class="" id="the-search-bar">
            <div class="flex-item-search-bar" id="fi-search-bar">

                <form class="search_form" action="" method="post">
                    <div class="flex-item-search" >  
                        <input name="search"  class="flex-item-search form-control"size="30" type="text" placeholder="Search beneficiaries..." />
                    </div>

                   

                    <div class="flex-item-by">
                        <label>By :</label>
                    </div>

                    <div class="flex-item-search-by">
                        <select name="by" class="form-control mb-3 mb-3" >
                            <option value="wa">Wallet Address</option>
                            <option value="name">Name</option>
                        </select>
                    </div>
                    <div class="flex-item-search-by" >
                        <button type="submit"  class="btn btn-secondary" name="submit" id="search">Search</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
            </div>
        </div>
    </div>

    
    <div class="flex-container">
        
        <?php
            $result = $conn->query($sql0);
            $isBenefPresent = 0;
            $back_button = FALSE;

            if ($result->num_rows > 0) {
            // output data of each row
            $i = 0;
            while($row = $result->fetch_assoc()) {
                $i++;

                if (isset($_POST['submit'])) {
                    $back_button = TRUE;
                    $search = $_POST['search'];
                    $by = $_POST['by'];

                    if ($by == "name") {
                        $sql1 = "SELECT user_id, name,  wallet_address FROM user
                        WHERE user_id=".$row["benef_user_id"]." AND (name LIKE '%$search%' OR CONCAT(name) LIKE '%$search%')";
                    }
                    else {
                        $sql1 = "SELECT user_id, name, wallet_address FROM user
                        WHERE user_id=".$row["benef_user_id"]." AND wallet_address LIKE '$search'";
                    }
                }
                else {
                    $sql1 = "SELECT user_id, name, wallet_address
                             FROM user WHERE user_id=".$row["benef_user_id"];
                }

                $result1 = $conn->query($sql1);
                if ($result1->num_rows > 0) {
                    $isBenefPresent = 1;
                    $row1 = $result1->fetch_assoc();
                ?>

                    <div class="flex-item">
                        <div class="flex-item-1">
                            <p id="id"><?php echo $i . "."; ?></p>
                        </div>
                        <div class="flex-item-2">
                            <p id="name"><?php echo $row1["name"]; ?></p>
                            <p id="acno"><?php echo "Wallet Address : " . $row1["wallet_address"]; ?></p>
                        </div>
                        <div class="flex-item-1">
                            <div class="dropdown">
                                <!--Ware dynamically naming each dropdown for every entry in the loop and
                                    passing the respective integer value in the dropdown_func().
                                    This creates adynamic anchor for each button-->
                              
                            
                                <!--Pass the customer trans_id as a get variable in the link-->
                                <a href="./send_coins.php?user_id=<?php echo $row1["user_id"] ?>" class="btn btn-primary">Send</a>
                                <a href="./delete_beneficiary.php?user_id=<?php echo $row1["user_id"] ?>" class="btn btn-primary"
                                     onclick="return confirm('Are you sure?')">Delete</a>
                              </div>
                            </div>
                        </div>
                    </div>

            <?php }}}

            if ($isBenefPresent == 0) { ?>
                <p id="none"> No beneficiaries found :(</p>
            <?php }
            if ($back_button) { ?>
                <div class="flex-container-bb">
                    <div class="back_button">
                        <a href="./beneficiary.php" class="button">Go Back</a>
                    </div>
                </div>
            <?php }
            $conn->close(); ?>
    </div>

                    

                
        <footer class="footer">
          <div class="footer__block block no-margin-bottom">
            <div class="container-fluid text-center">
              <!-- Please do not remove the backlink to us unless you support us at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
               <p class="no-margin-bottom">2021 &copy; veritas university abuja</p>
            </div>
          </div>
        </footer>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="js/charts-home.js"></script>
    <script src="js/front.js"></script>
  </body>
</html>