<?php
    include "validate_admin.php";
    include "header.php";
    include "admin_sidebar.php";

?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/register_user_style.css">
</head>

<body>
    <form class="add_customer_form" action="register_user_action.php" method="post">
        <div class="flex-container-form_header">
            <h1 id="form_header">Please fill the deatils to register a user </h1>
        </div>

        <div class="flex-container">
            <div class=container>
                <label>Name :</label><br>
                <input name="name" size="30" type="text" required />
            </div>
         
        </div>

        <div class="flex-container">
            <div class=container>
                <label>Gender :</label>
            </div>
            <div class="flex-container-radio">
                <div class="container">
                    <select name ="gender" id="gender">
                        <option value ="male">Male</option>
                        <option value ="female">Female</option>
                        <option value ="others">Others</option>
                    </select>
                </div>
                
            </div>
        </div>
        
        <div class="flex-container">
            <div class=container>
                <label>User Type :</label>
            </div>
            <div class="flex-container-radio">
                <div class="container">
                    <select name ="user_type" id="user_type">
                        <option value ="staff">Staff</option>
                        <option value ="student">Student</option>
                        <option value ="vendor">Vendor</option>
                    </select>
                </div>
                 
            </div>
        </div>

        <div class="flex-container">
            <div class=container>
                <label>Department :</label><br>
                <input name="department" size="30"type="text" required />
            </div>
        </div>
        <div class="flex-container">
            <div class=container>
                <label>Faculty :</label><br>
                <input name="faculty" size="30"type="text" required />
            </div>
        </div>
        <div class="flex-container">
            <div class=container>
                <label>Email-ID :</label><br>
                <input name="email" size="30" type="text" required />
            </div>
            <div  class=container>
                <label>Phone No. :</b></label><br>
                <input name="phno" size="30" type="text" required />
            </div>
        </div>

        <div class="flex-container">
            <div class=container>
                <label>Address :</label><br>
                <textarea name="address" required /></textarea>
            </div>
        </div>

        <div class="flex-container">
            <div class=container>
                <label>wallet_address :</label><br>
                <input name="wallet_address" size="25" type="text" required />
            </div>
        </div>

        <div class="flex-container">
            <div class=container>
                <label>VUNACOIN Deposit :</label><br>
                <input name="opening_balance" size="20" type="text" required />
            </div>
            <div  class=container>
                <label>PIN :</b></label><br>
                <input name="pin" size="15" type="text" required />
            </div>
        </div>

        <div class="flex-container">
            <div class=container>
                <label>Username :</label><br>
                <input name="username" size="30" type="text" required />
            </div>
            <div  class=container>
                <label>Password :</b></label><br>
                <input name="pwd" size="30" type="text" required />
            </div>
        </div>

        <div class="flex-container">
            <div class="container">
                <button type="submit">Submit</button>
            </div>

        </div>

    </form>



</body>
</html>
