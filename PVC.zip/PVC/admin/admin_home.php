<?php
    include "validate_admin.php";
    include "header.php";
     include "admin_sidebar.php";
     include "admin_navbar.php";
    

     
     
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
       body {
    margin: 0;
    padding: 0;
    background-color:  white;
}
        </style>

    <link rel="stylesheet" href="css/admin_home_style.css">
</head>

<body>
    <div class="flex-container">
       <!-- <center>
        <div class="flex-item">
            <h1 id="user" style="color:black;">
                Welcome Admin !
            </h1>
            <p id="user" style="max-width:800px">
              your welcome admin
            </p>
        </div>
        </center> -->
    </div>

</body>
</html>


