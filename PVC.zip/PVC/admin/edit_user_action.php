<?php
    /* Avoid multiple sessions warning
    Check if session is set before starting a new one. */
    if(!isset($_SESSION)) {
        session_start();
    }

    include "validate_admin.php";
    include "connect.php";
    include "header.php";
    include "admin_navbar.php";
    include "admin_sidebar.php";


    if (isset($_GET['user_id'])) {
        $_SESSION['user_id'] = $_GET['user_id'];
    }
    $name = mysqli_real_escape_string($conn, $_POST["name"]);
    $gender = mysqli_real_escape_string($conn, $_POST["gender"]);
    $user_type = mysqli_real_escape_string($conn, $_POST["user_type"]);
    $department = mysqli_real_escape_string($conn, $_POST["department"]);
    $faculty = mysqli_real_escape_string($conn, $_POST["faculty"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $phno = mysqli_real_escape_string($conn, $_POST["phone_no"]);
    $address = mysqli_real_escape_string($conn, $_POST["address"]);
   // $wallet_address = mysqli_real_escape_string($conn, $_POST["wallet_address"]);

   // $pin = mysqli_real_escape_string($conn, $_POST["pin"]);
  //  $user_username = mysqli_real_escape_string($conn, $_POST["username"]);
    $user_pwd = mysqli_real_escape_string($conn, $_POST["pwd"]);
  //$newpass = sha1($user_pwd); //This will make your password encrypted into sha1, a high security hash
    $sql0 = "UPDATE user SET name = '$name',
                                 gender = '$gender',
                                 user_type = '$user_type',
                                 department = '$department',
                                 faculty = '$faculty',
                                 email = '$email',
                                 phone_no = '$phno',
                                 address = '$address',
                                 pwd = '$user_pwd'
                            WHERE user_id=".$_SESSION['user_id'];


?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/action_style.css">
</head>

<body>
    <div class="flex-container">
        <div class="flex-item">
            <?php
                if (($conn->query($sql0) === TRUE)) { ?>
                    <p id="info"><?php echo "Values Updated Successfully !"; ?></p>
                <?php
                }
                else { ?>
                    <p id="info"><?php echo "Error: " . $sql0 . "<br>" . $conn->error . "<br>"; ?></p>
                <?php
                }
            ?>
        </div>
        <?php $conn->close(); ?>

        <div class="flex-item">
            <a href="./manage_users.php" class="button">Go Back</a>
        </div>

    </div>

</body>
</html>
