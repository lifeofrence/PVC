<?php
    include "validate_admin.php";
    include "connect.php";
    include "header.php";
    include "admin_sidebar.php";
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/action_style.css">
</head>

<?php
$name = mysqli_real_escape_string($conn, $_POST["name"]);
$gender = mysqli_real_escape_string($conn, $_POST["gender"]);
$user_type = mysqli_real_escape_string($conn, $_POST["user_type"]);
$department = mysqli_real_escape_string($conn, $_POST["department"]);
$faculty = mysqli_real_escape_string($conn, $_POST["faculty"]);
$email = mysqli_real_escape_string($conn, $_POST["email"]);
$phno = mysqli_real_escape_string($conn, $_POST["phno"]);
$address = mysqli_real_escape_string($conn, $_POST["address"]);
$wallet_address = mysqli_real_escape_string($conn, $_POST["wallet_address"]);
$o_balance = mysqli_real_escape_string($conn, $_POST["opening_balance"]);
$pin = mysqli_real_escape_string($conn, $_POST["pin"]);
$user_username = mysqli_real_escape_string($conn, $_POST["username"]);
$user_pwd = mysqli_real_escape_string($conn, $_POST["pwd"]);

$sql0 = "SELECT MAX(user_id) FROM user";
$result = $conn->query($sql0);
$row = $result->fetch_assoc();
$id = $row["MAX(user_id)"] + 1;



$sql1 = "CREATE TABLE audit".$id."(
            trans_id INT NOT NULL AUTO_INCREMENT,
            trans_date DATETIME,
            remarks VARCHAR(255),
            debit INT,
            credit INT,
            balance INT,
            PRIMARY KEY(trans_id)
        )";

$sql2 = "CREATE TABLE beneficiary".$id."(
            benef_id INT NOT NULL AUTO_INCREMENT,
            benef_user_id INT UNIQUE,
            email VARCHAR(30) UNIQUE,
            phone_no VARCHAR(20) UNIQUE,
            wallet_address INT UNIQUE,
            PRIMARY KEY(benef_id)
        )";
      //  $newpass = sha1($user_pwd); //This will make your password encrypted into sha1, a high security hash
       // $newpin = md5($pin); //This will make your password encrypted into md5, a high security hash
$sql3 = "INSERT INTO user VALUES(
            NULL,
            '$name',
            '$gender',
            '$user_type',
            '$department',
            '$faculty',
            '$email',
            '$phno',
            '$address',
            '$wallet_address',
            '$o_balance',
            '$pin',
            '$user_username',
            '$user_pwd',
            NULL
        )";

$sql4 = "INSERT INTO audit".$id." VALUES(
            NULL,
            NOW(), 
            'Opening Balance',
            '0',
            '$o_balance',
            '$o_balance'
        )";

?>

<body>
    <div class="flex-container">
        <div class="flex-item">
            <?php
            if (($conn->query($sql3) === TRUE)) { ?>
                <p id="info"><?php echo "User created successfully !\n"; ?></p>
        </div>

        <div class="flex-item">
            <?php
            if (($conn->query($sql1) === TRUE)) { ?>
            
            <?php
            } else { ?>
                <p id="info"><?php
                echo "Error: " . $sql1 . "<br>" . $conn->error . "<br>"; ?></p>
            <?php } ?>
        </div>

        <div class="flex-item">
            <?php
            if (($conn->query($sql4) === TRUE)) { ?>
              
            <?php
            } else { ?>
                <p id="info"><?php
                echo "Error: " . $sql4 . "<br>" . $conn->error . "<br>"; ?></p>
            <?php } ?>
        </div>

        <div class="flex-item">
            <?php
            if (($conn->query($sql2) === TRUE)) { ?>
             
            <?php
            } else { ?>
                <p id="info"><?php
                echo "Error: " . $sql2 . "<br>" . $conn->error . "<br>"; ?></p>
            <?php } ?>
        </div>

            <?php
            } else { ?>
        </div>
        <div class="flex-item">
                <p id="info"><?php
                echo "Error: " . $sql3 . "<br>" . $conn->error . "<br>"; ?></p>
            <?php } ?>
        </div>
        <?php $conn->close(); ?>

        <div class="flex-item">
            <a href="./register_user.php" class="button">Add Again</a>
        </div>

    </div>

</body>
</html>
