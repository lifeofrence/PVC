<?php
    include "header.php";
    if (isset($_GET['loginFailed'])) {
        $message = "Invalid Credentials ! Please try again.";
        echo "<script type='text/javascript'>alert('$message');</script>";
    }
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="css/home_style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body{
            background-color:black;

        }
        h1, p{
            background-color:white; 
        }
        </style>
</head>


<body>
<div class="flex-item-login">
                        <h2>VUNACOIN</h2>
                    </div>
    <form action="./admin_login_action.php" method="post">
        <center>  
                <div class="flex-item-login">
                        <h2>ADMIN LOGIN</h2>
                    </div>

                    <div class="flex-item">
                        <input type="text" name="admin_username" placeholder="Enter your Username" required>
                    </div>

                    <div class="flex-item">
                        <input type="password" name="admin_psw" placeholder="Enter your Password" required>
                    </div>

                    <div class="flex-item">
                        <button type="submit">Login</button>
                    </div>
                </div>
                  
        </center>
    </form>

</body>
</html>
