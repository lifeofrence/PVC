<?php
    /* Avoid multiple sessions warning
    Check if session is set before starting a new one. */
    if(!isset($_SESSION)) {
        session_start();
    }

    include "validate_admin.php";
    include "connect.php";
    include "header.php";
    include "admin_navbar.php";
    include "admin_sidebar.php";


    if (isset($_GET['user_id'])) {
        $_SESSION['user_id'] = $_GET['user_id'];
    }

    $sql0 = "SELECT * FROM user WHERE user_id=".$_SESSION['user_id'];
    $sql1 = "SELECT * FROM audit".$_SESSION['user_id']." WHERE trans_id=(
                    SELECT MAX(trans_id) FROM audit".$_SESSION['user_id'].")";

    $result0 = $conn->query($sql0);
    $result1 = $conn->query($sql1);

    if ($result0->num_rows > 0) {
        // output data of each row
        while($row = $result0->fetch_assoc()) {
        $name = $row["name"];
        $gender = $row["gender"];
        $user_type = $row["user_type"];
        $department = $row["department"];
        $faculty = $row["faculty"];
        $email = $row["email"];
        $phno = $row["phone_no"];
        $address = $row["address"];
        $wallet_address = $row["wallet_address"];
       // $pin = $row["pin"];
      //  $user_username = $row["username"];
        $user_pwd = $row["pwd"];
        }
    }

    if ($result1->num_rows > 0) {
        // output data of each row
        while($row = $result1->fetch_assoc()) {
            $balance = $row["balance"];
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/user_add_style.css">
</head>

<body>
<form class="add_customer_form" action="./credit_user_action.php" method="post">
        <div class="flex-container-form_header">
            <h1 id="form_header">Credit/Debit User . . .</h1>
        </div>

       
        <div class="flex-container">
            <div class=container>
                <label>Name :</label><br>
                <input name="name" size="30" type="text" value="<?php echo $name ?>"  />
            </div>
        </div>


        <div class="flex-container">
            <div class=container>
                <label>wallet_address : <?php echo $wallet_address ?> </label><br>
               
            </div>
        </div>

        <div class="flex-container">
            <div class=container>
                <label>Credit Wallet : <?php echo $balance ?> </label><br>
                <input name="balance" size="20" type="text" />
            </div>
          
        </div>

        <div class="flex-container">
            <div class="container">
                <a href="./edit_users.php" class="button">Go Back</a>
            </div>
            <div class="container">
                <button type="submit">Update</button>
            </div>
        </div>

    </form>


</body>
</html>
