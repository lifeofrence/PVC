<?php

$user_type = $_POST["user_type"];
$user_id = $_POST["user_id"];
$user_name = $_POST["name"];
$user_department = $_POST["department"];
$user_faculty = $_POST["faculty"];
$user_gender = $_POST["gender"];
$user_phone_no = $_POST["phone_no"];
$user_email = $_POST["email"];
$user_address = $_POST["address"];
$user_password= $_POST["password"];


$con = mysqli_connect ('localhost','root','','pvc');
$sql = "insert into user_tbl values('".$user_type."', '".$user_id."','".$user_name."','".$user_department."','".$user_faculty."',
            '".$user_phone_no."','".$user_email."','".$user_address."','".$user_password."',); ";

 {
    echo "Registration sucessful";

}
 else
 {
     echo "Error while Registering"
 }
 mysqli_close($con);

?>