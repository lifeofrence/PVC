
<?php
    /* Avoid multiple sessions warning
    Check if session is set before starting a new one. */
    if(!isset($_SESSION)) {
        session_start();
    }

    include "validate_user.php";
    include "connect.php";
    include "session_timeout.php";

    $id = $_SESSION['loggedIn_user_id'];

    $sql0 = "SELECT * FROM user WHERE user_id=".$id;
    $sql1 = "SELECT * FROM audit".$id." WHERE trans_id=(
                    SELECT MAX(trans_id) FROM audit".$id.")";

    $result0 = $conn->query($sql0);
    $result1 = $conn->query($sql1);

    if ($result0->num_rows > 0) {
        // output data of each row
        while($row = $result0->fetch_assoc()) {
            $name = $row["name"];
            $gender = $row["gender"];
            $user_type = $row["user_type"];
            $department = $row["department"];
            $faculty = $row["faculty"];
            $email = $row["email"];
            $phno = $row["phone_no"];
            $address = $row["address"];
            $wallet_address = $row["wallet_address"];
            $pin = $row["pin"];
            $user_username = $row["username"];
            $user_pwd = $row["pwd"];
        }
    }

    if ($result1->num_rows > 0) {
        // output data of each row
        while($row = $result1->fetch_assoc()) {
            $balance = $row["balance"];
        }
    }
?>
<?php 

error_reporting(0); 
?> 
<?php 
  if(!isset($_SESSION)) {
    session_start();
}
$id = $_SESSION['loggedIn_user_id'];

  // If upload button is clicked ... 
  $db = mysqli_connect("localhost", "root", "", "vunacoin"); 

  if (isset($_POST['upload'])) { 

  

    $filename = $_FILES["uploadfile"]["name"]; 

    $tempname = $_FILES["uploadfile"]["tmp_name"];     

        $folder = "img/".$filename; 

          

   

  

        // Get all the submitted data from the form 

        $sq2 = "UPDATE user  
        SET filename ='$filename'
            WHERE user_id=".$id;


        // Execute query 

        mysqli_query($db, $sq2); 

          

        // Now let's move the uploaded image into the folder: image 

        if (move_uploaded_file($tempname, $folder))  { 

           echo "Image uploaded successfully"; 

        }else{ 

           echo "Failed to upload image"; 

      } 
      
      
  } 
  


?> 

<!DOCTYPE html>
<html>
  <head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>vunacoin</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
   <link rel = "stylesheet" href = "https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
    <!-- Custom Font Icons CSS-->
    <link rel="stylesheet" href="css/font.css">
    <!-- Google fonts - Muli-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Muli:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" >
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.ico">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
  <header class="header">   
  <nav class="navbar navbar-expand-lg">
        <div class="search-panel">
          <div class="search-inner d-flex align-items-center justify-content-center">
         
            
          </div>
        </div>
        <div class="container-fluid d-flex align-items-center justify-content-between">
          <div class="navbar-header">
            <!-- Navbar Header-->
            <a href="./user_home.php" class="navbar-brand">
              <div class="brand-text brand-big visible text-uppercase"><strong class="text-primary">vuna</strong><strong>coin</strong></div>
              <div class="brand-text brand-sm"><strong class="text-primary">vuna</strong><strong>coin</strong></div></a>
            <!-- Sidebar Toggle Btn-->
            <button class="sidebar-toggle"><i class="fa fa-long-arrow-left"></i></button>
          </div>
          <div class="right-menu list-inline no-margin-bottom">    
            
            <div class="list-inline-item dropdown"><a id="navbarDropdownMenuLink1" href="http://example.com" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link messages-toggle">
            <i class="fa fa-envelope">News Update</i><span class="badge dashbg-1">1</span> 
              <div aria-labelledby="navbarDropdownMenuLink1" class="dropdown-menu messages">
                <a href="#" class="dropdown-item message d-flex align-items-center">
                  <div class="profile"><img src="img/vunalogo.jpg" alt="..." class="img-fluid">
                    
                  </div>
                  
    <div class="flex-container">
        <?php
            $sql0 = "SELECT id, title, created FROM news ORDER BY created DESC";
            $result = $conn->query($sql0);

            if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $id = $row["id"];
                $sql1 = "SELECT body FROM news_body WHERE id=$id";
                $result1 = $conn->query($sql1); ?>

                <div class="flex-item">
                    <div class="flex-container-title">
                        <h1 id="title"><?php echo $row["title"] . "<br>"; ?></h1>
                    </div>
                    <div class="flex-container-title">
                        <p id="date"><?php echo "Date : " .
                            date("d/m/Y", strtotime($row["created"])); ?></p>
                    </div>
                    <div class="flex-container-body">
                        <p id="news_body"><?php while($row1 = $result1->fetch_assoc()) {
                            echo $row1["body"]; } ?></p>
                    </div>
                </div>

            <?php }
            } else {
                echo "No news available !";
            }
            $conn->close();
        ?>
    </div>
                  <div class="content"> </div></a><a href="#" class="dropdown-item text-center message"> <strong>See All News <i class="fa fa-angle-right"></i></strong></a></div>
            </div>
            <!-- Tasks end-->
           
            <!-- Log out               -->
            <div class="list-inline-item logout">                   <a id="logout" href="./logout_action.php" class="nav-link">Logout <i class="icon-logout"></i></a></div>
          </div>
        </div>
      </nav>
    </header>
    <div class="d-flex align-items-stretch">
      <!-- Sidebar Navigation-->
      <nav id="sidebar">
        <!-- Sidebar Header-->
        <div class="sidebar-header d-flex align-items-center">
        
             <div class="img-fluid rounded-circle " width="120px" height="120px">
          <?php 
          
$id = $_SESSION['loggedIn_user_id'];

// If upload button is clicked ... 
$db = mysqli_connect("localhost", "root", "", "vunacoin"); 

          $sql3 = "SELECT * FROM user WHERE user_id=".$id;
    
            $result2 = mysqli_query($db, $sql3); 
  
          while($data = mysqli_fetch_array($result2)) 
        { 
      
            echo'<img src="img/'.$data['filename'].'" class="img-fluid rounded-circle";>';
          }  ?> 
        
      </div>
          <div class="title">
            
            
          </div>
        </div>
        <!-- Sidebar Navidation Menus--><span class="heading">
    </span>  
    <h1> <?php echo $row0["name"] ?></h1>
        <ul class="list-unstyled">
        <li class="active"><a href="./user_home.php"> <i class="fa fa-home"></i>Home </a></li>
                <li class="active"><a href="./user_profile.php"> <i class="fa fa-user"></i>Profile </a></li>
                <li class="active"><a href="./transactions_history.php"> <i class="fa fa-history"></i>Transaction History </a></li>
                <li class="active"><a href="./beneficiary.php"> <i class="fa fa-bar-chart"></i>Transfer Coin </a></li>
                <li class="active"><a href="./logout_action.php"> <i class="icon-logout"></i>Logout </a></li>
        
      </nav>
      <!-- Sidebar Navigation end-->
      <div class="bg-white   page-content">
        <div class="page-header">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Profile</h2>
          </div>
        </div>
        <form method="POST" action="upload.php" enctype="multipart/form-data"> 

    <input type="file" name="uploadfile" value=""/> 

      

    <div> 

        <button class="btn btn-secondary" type="submit" name="upload">Upload Profile Pic</button> 

      </div> 

</form> 
        <form class="add_customer_form" action="user_profile_action.php" method="post">
        <div class="flex-container-form_header">
            <h2 id="form_header">Your account details </h2>
            <div id="content"> 

  


</div> 
            <div class="flex-container">
            <div class=container>
                <label>Name : <label id="info_label"><?php echo $name ?></label></label>
            </div>
        </div>

        <div class="flex-container">
            <div class=container>
                <label>Wallet Address : <label id="info_label"><?php echo $wallet_address ?></label></label>
            </div>
        </div>

        <div class="flex-container">
            <div class=container>
                <label>Coins Balance : <label id="info_label"><?php echo number_format($balance) ?></label></label>
            </div>
        </div>

        <div class="flex-container">
            <div class=container>
                <label>Gender :
                    <label id="info_label">
                    <?php
                        if ($gender == "male") {echo "Male";}
                        elseif ($gender == "female") {echo "Female";}
                        else {echo "Others";}
                    ?>
                    <label>
                </label>
            </div>
        </div>

        <div class="flex-container">
            <div class=container>
                <label>User Type :
                    <label id="info_label">
                    <?php
                        if ($user_type == "staff") {echo "Staff";}
                        elseif ($user_type == "student") {echo "Student";}
                        else {echo "Vendor";}
                    ?>
                    <label>
                </label>
            </div>
        </div>

        <div class="flex-container">
            <div class=container>
                <label>Department : <label id="info_label"><?php echo $department ?></label></label>
            </div>
        </div>

        <div class="flex-container">
            <div class=container>
                <label>Faculty : <label id="info_label"><?php echo $faculty ?></label></label>
            </div>
        </div>


        <div class="flex-container">
            <div class=container>
                <label>Email-ID :</label><br>
                <input name="email" size="30" type="text" value="<?php echo $email ?>" required />
            </div>
            <div class=container>
                <label>Username   :  <label><label id="info_label"><?php echo $user_username  ?></label></label>
                
            </div>
        </div>

        <div class="flex-container">
            <div  class=container>
                <label>Phone No. : <label id="info_label"><?php echo $phno ?></label></label>
            </div>
        </div>

        <div class="flex-container">
            <div class=container>
                <label>Address :</label><br>
                <textarea name="address" required /><?php echo $address ?></textarea>
            </div>
        </div>

 

        <div class="flex-container">
            
            <div class="container">
            <button class="btn btn-primary" type="submit">Update </button>
            </div>
            <br>
            <div class="container">
                <a href="./pass_change.php" class="btn btn-secondary">Change Password/PIN</a>
               
            </div>
        </div>
        </div>
    

     
    </form>

        <footer class="footer">
          <div class="footer__block block no-margin-bottom">
            <div class="container-fluid text-center">
              <!-- Please do not remove the backlink to us unless you support us at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
               <p class="no-margin-bottom">2021 &copy; veritas university abuja</p>
            </div>
          </div>
        </footer>
      </div>
    </div>
    
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="js/charts-home.js"></script>
    <script src="js/front.js"></script>
  </body>
</html>