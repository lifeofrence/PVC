<?php
    include "validate_user.php";
    include "connect.php";
  //  include "header.php";
  //  include "user_navbar.php";
  //  include "user_sidebar.php";
    include "session_timeout.php";

    $id = $_SESSION['loggedIn_user_id'];

    $sql0 = "SELECT * FROM user WHERE user_id=".$id;
    $result0 = $conn->query($sql0);
    $row0 = $result0->fetch_assoc();

    $sql1 = "SELECT * FROM audit".$id." WHERE trans_id=(
                    SELECT MAX(trans_id) FROM audit".$id.")";
    $result1 = $conn->query($sql1);
    $row1 = $result1->fetch_assoc();

    if ($row1["debit"] == 0) {
        $transaction = $row1["credit"];
        $type = "credit";
    }
    else {
        $transaction = $row1["debit"];
        $type = "debit";
    }

    $time = strtotime($row1["trans_date"]);
    $sanitized_time = date("d/m/Y, g:i A", $time);

    $sql2 = "SELECT COUNT(*) FROM beneficiary".$id;
    $result2 = $conn->query($sql2);
    $row2 = $result2->fetch_assoc();
    
?>
<?php
    include "connect.php";

    /* Avoid multiple sessions warning
    Check if session is set before starting a new one. */
    if(!isset($_SESSION)) {
        session_start();
    }

    if (isset($_SESSION['loggedIn_user_id'])) {
        $sql0 = "SELECT * FROM user WHERE user_id=".$_SESSION['loggedIn_user_id'];
        $result = $conn->query($sql0);
        $row = $result->fetch_assoc();
    }
?>

<!DOCTYPE html>
<html>
  <head> 
  <style>
    body{
        background-color:black;
    }
   
    </style>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>vunacoin</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel = "stylesheet" href = "https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
   <link rel = "stylesheet" href = "https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
    <!-- Custom Font Icons CSS-->
    <link rel="stylesheet" href="css/font.css">
    <!-- Google fonts - Muli-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Muli:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.ico">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> <!--for icons-->
    <link rel="stylesheet" href="../lib/w3.css">  <!--for animations-->
    <link rel="stylesheet" href="../../cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--for icons-->
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
  <header class="header">   
      <nav class="navbar navbar-expand-lg">
        <div class="search-panel">
          <div class="search-inner d-flex align-items-center justify-content-center">
         
            
          </div>
        </div>
        <div class="container-fluid d-flex align-items-center justify-content-between">
          <div class="navbar-header">
            <!-- Navbar Header-->
            <a href="./user_home.php" class="navbar-brand">
              <div class="brand-text brand-big visible text-uppercase"><strong class="text-primary">vuna</strong><strong>coin</strong></div>
              <div class="brand-text brand-sm"><strong class="text-primary">vuna</strong><strong>coin</strong></div></a>
            <!-- Sidebar Toggle Btn-->
            <button class="sidebar-toggle"><i class="fa fa-long-arrow-left"></i></button>
          </div>
          <div class="right-menu list-inline no-margin-bottom">    
            
            <div class="list-inline-item dropdown">
              <a id="navbarDropdownMenuLink1" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link messages-toggle">
              <i class="fa fa-envelope">News Update</i><span class="badge dashbg-1">1</span> 
            </a>
              <div aria-labelledby="navbarDropdownMenuLink1" class="dropdown-menu messages ">
                <a href="#" class="dropdown-item message d-flex align-items-center">
                  <div class="profile"><img src="img/vunalogo.jpg" alt="..." class="img-fluid">
                    <div class="status online"></div>
                  </div>
                  <center>         
    <div class="">
        <?php
            $sql0 = "SELECT id, title, created FROM news ORDER BY created DESC";
            $result = $conn->query($sql0);

            if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $id = $row["id"];
                $sql1 = "SELECT body FROM news_body WHERE id=$id";
                $result1 = $conn->query($sql1); ?>

                <div class="flex-item">
                    <div class="flex-container-title">
                        <h1 id="title"><?php echo $row["title"] . "<br>"; ?></h1>
                    </div>
                    <div class="flex-container-title">
                        <p id="date"><?php echo "Date : " .
                            date("d/m/Y", strtotime($row["created"])); ?></p>
                    </div>
                    <div class="flex-container-body">
                        <p id="news_body"><?php while($row2 = $result1->fetch_assoc()) {
                            echo $row2["body"]; } ?></p>
                    </div>
                       
                </div>
               
            <?php }
            } else {
                echo "No news available !";
            }
            $conn->close();
        ?>
    </div>
    </center>
                  <div class="content"> </div></a><a href="#" class="dropdown-item text-center message"> <strong>See All News <i class="fa fa-angle-right"></i></strong></a></div>
            </div>
            <!-- Tasks end-->
           
            <!-- Log out               -->
            <div class="list-inline-item logout">                   <a id="logout" href="./logout_action.php" class="nav-link">Logout <i class="fas fa-sign-out-alt"></i></a></div>
          </div>
        </div>
      </nav>
    </header>
    <div class="d-flex align-items-stretch">
      <!-- Sidebar Navigation-->
      <nav id="sidebar">
        <!-- Sidebar Header-->
        <div class="sidebar-header d-flex align-items-center">
        
             <div class="img-fluid rounded-circle " width="50" height="50">
          <?php 
          
$id = $_SESSION['loggedIn_user_id'];

// If upload button is clicked ... 
$db = mysqli_connect("localhost", "root", "", "vunacoin"); 

          $sql3 = "SELECT * FROM user WHERE user_id=".$id;
    
            $result2 = mysqli_query($db, $sql3); 
  
          while($data = mysqli_fetch_array($result2)) 
        { 
      
            echo'<img src="img/'.$data['filename'].'" class="img-fluid rounded-circle";>';
          }  ?> 
        
      </div>
          <div class="title">
            
            
          </div>
        </div>
        <!-- Sidebar Navidation Menus--><span class="heading">
    </span>  
    <!-- <h1 class="col-md-3 col-sm-6 brand-text brand-sm list-unstyled"> </h1> -->
    <ul class="list-unstyled">
      <li class=""><h5> <strong><?php echo $row0["name"] ?></strong></h5></li>
    </ul>
        <ul class="list-unstyled">
              <li class="active"><a href="./user_home.php"> <i class="fa fa-home"></i>Home </a></li>
                <li class="active"><a href="./user_profile.php"> <i class="fa fa-user"></i>Profile </a></li>
                <li class="active"><a href="./transactions_history.php"> <i class="fa fa-history"></i>Transaction History </a></li>
                <li class="active"><a href="./beneficiary.php"> <i class="fa fa-bar-chart"></i>Transfer Coin </a></li>
                <li class="active"><a href="./logout_action.php"> <i class="icon-logout"></i>Logout </a></li>
      </nav>
      <!-- Sidebar Navigation end-->
      <div class="bg-white page-content ">
        <div class="page-header">
          <div class="container-fluid">
          <div class="news">
            <marquee behavior="scroll" direction="left" scrollamount="10">
            <strong><i>DONT FORGET TO ALWAYS CHECK YOUR MESSAGE FOR NEWS UODATE</i> </strong> 
            </marquee></div>
            <h2 class="h5 no-margin-bottom">Welcome</h2>
          </div>
        </div>
        <section class="no-padding-top no-padding-bottom ">
          <div class="container-fluid ">
            <div class="row">
              <!-- <div class="col-md-3 col-sm-6">
              
                  <div class="progress-details d-flex align-items-end justify-content-between">
                    <div class="title">
                      <div class="icon"></i></div><strong></strong>
                    </div>
                  
                  </div>
                  <div class="progress progress-template">
                    <div role="progressbar" style="width: 30%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" class="progress-bar progress-bar-template dashbg-1"></div>
                  </div>
                
              </div> -->
              <div class=" col-sm-6">
                
                  <div class="progress-details d-flex align-items-end justify-content-between">
                    <div class="title">
                      <div class="icon"></i></div><strong>WALLET ID: </strong>
                    </div>
                    <div class="number dashtext-2"><?php echo $row0["wallet_address"]; ?></div>
                  </div>
                  <div class="progress progress-template">
                    <div role="progressbar" style="width: 70%" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" class="progress-bar progress-bar-template dashbg-2"></div>
                  </div>
                
              </div>
              <div class="col-sm-6">
                
                  <div class="progress-details d-flex align-items-end justify-content-between">
                    <div class="title">
                      <div class="icon">VUNACOIN</i></div><strong>Balance: </strong>
                    </div>
                    <div class="number dashtext-3"><?php echo number_format($row1["balance"]); ?> </div>
                  </div>
                  <div class="progress progress-template">
                    <div role="progressbar" style="width: 55%" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100" class="progress-bar progress-bar-template dashbg-3"></div>
                 
                </div>
              </div>
             
        </section>
  <div class="">
                
                  <div class="progress-details d-flex align-items-end justify-content-between  ">

            <!-- <br>&#9656 You have <?php echo $row2["COUNT(*)"]; ?> beneficiaries. -->
           <br><br><br> <br><i class="fa fa-user list-unstyled" ></i><br>Your last transaction (<?php echo $type; ?>) of &nbsp<?php
            echo number_format($transaction); ?> VUNACOIN
            on <?php echo $sanitized_time; ?>, was: "<?php echo $row1["remarks"]; ?>".
        </p>
    </div>
</div>
        <footer class="footer">
          <div class="footer__block block no-margin-bottom">
            <div class="container-fluid text-center">
              <!-- Please do not remove the backlink to us unless you support us at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
               <p class="no-margin-bottom">2021 &copy; veritas university abuja</p>
            </div>
          </div>
        </footer>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="js/charts-home.js"></script>
    <script src="js/front.js"></script>
  </body>
</html>